De titel van elke files is vanzelfsprekend.

voor de test van elke python implementatie, ik heb gewoon in de main sommige bewerking geschreven.
met elke keer een print erachter. ik heb geen speciale doctest gedaan dus voor te testen moeten enkel
de originele python file laten lopen.

MVG
Wei